# BSC Master (نسخه لوکال)
1. `docker compose up -d`   ← PostgreSQL
2. `cd backend && pip install -r requirements.txt && python seed.py && uvicorn app.main:app --reload`
3. `cd frontend && npm install && npm run dev`  → http://localhost:5173  (مستندات API: http://localhost:8000/docs)
بدون Docker برای تست سریع: `DATABASE_URL=sqlite:///bsc.db` قبل از اجرای seed و uvicorn.
