import { useEffect, useState, useCallback } from "react";

const api = (u, o) => fetch("/api" + u, o).then((r) => r.json());
const fa = (n) => (n == null ? "—" : Number(n).toLocaleString("fa-IR", { maximumFractionDigits: 1 }));
const ST = { green: "سبز", yellow: "زرد", red: "قرمز" };
const Dot = ({ s, v }) => <span className={"dot " + (s || "")}>{fa(v)}</span>;

function OrgTree({ orgs, parent = null, sel, onSel, depth = 0 }) {
  return orgs.filter((o) => o.parent_id === parent).map((o) => (
    <div key={o.id}>
      <button className={"org" + (sel === o.id ? " on" : "")} style={{ paddingRight: 10 + depth * 16 }} onClick={() => onSel(o.id)}>{o.name}</button>
      <OrgTree orgs={orgs} parent={o.id} sel={sel} onSel={onSel} depth={depth + 1} />
    </div>
  ));
}

function IndicatorRow({ i, periodId, reload }) {
  const [t, setT] = useState(i.target ?? "");
  const [a, setA] = useState(i.actual ?? "");
  const save = async () => {
    const num = (v) => (v === "" ? null : Number(v));
    await api("/measurements", { method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ indicator_id: i.id, period_id: periodId, target: num(t), actual: num(a) }) });
    reload();
  };
  return (
    <tr>
      <td>{i.title} <span className="small">({i.unit}{i.higher_is_better ? "" : "، کمتر بهتر"})</span></td>
      <td className="small">{i.method === "threshold" ? `آستانه ${fa(i.yellow_limit)}/${fa(i.green_limit)}` : "درصد تحقق"}</td>
      <td>{i.method === "threshold" ? "—" : <input value={t} onChange={(e) => setT(e.target.value)} onBlur={save} />}</td>
      <td><input value={a} onChange={(e) => setA(e.target.value)} onBlur={save} /></td>
      <td><Dot s={i.status} v={i.score} /></td>
    </tr>
  );
}

function Scorecard({ sc, periodId, reload }) {
  return sc.perspectives.map(({ perspective: p, objectives, score, status }) => (
    <section key={p.id} className={"persp " + (status || "")}>
      <header><span>منظر {p.name}</span><Dot s={status} v={score} /></header>
      {objectives.length === 0 && <div className="empty">هدفی برای این منظر ثبت نشده است. از <code>POST /api/objectives</code> اضافه کنید.</div>}
      {objectives.map((o) => (
        <div className="obj" key={o.id}>
          <h4><span>{o.title}</span><Dot s={o.status} v={o.score} /></h4>
          {o.indicators.length > 0 && (
            <table><thead><tr><th>شاخص</th><th>روش</th><th>هدف</th><th>واقعی</th><th>امتیاز</th></tr></thead>
              <tbody>{o.indicators.map((i) => <IndicatorRow key={i.id + "-" + periodId} i={i} periodId={periodId} reload={reload} />)}</tbody></table>
          )}
          {o.children.length > 0 && (
            <div>
              <span className="small">تراز‌شده با زیرمجموعه‌ها — امتیاز تجمیعی </span><Dot s={o.aligned_status} v={o.aligned_score} />
              <div>{o.children.map((k) => <span className="chip" key={k.objective_id}>{k.title}: {fa(k.score)} (وزن {fa(k.weight)})</span>)}</div>
            </div>
          )}
        </div>
      ))}
    </section>
  ));
}

function StrategyMap({ sc, causes }) {
  const all = sc.perspectives.flatMap((p) => p.objectives);
  const title = (id) => all.find((o) => o.id === id)?.title;
  return (
    <div className="map">
      {[...sc.perspectives].map(({ perspective: p, objectives }) => (
        <div className="band" key={p.id}>
          <strong>{p.name}</strong>
          <div className="lane">
            {objectives.map((o) => {
              const out = causes.filter((c) => c.from_id === o.id).map((c) => title(c.to_id)).filter(Boolean);
              return (
                <div className={"card " + (o.status || "")} key={o.id}>
                  <div>{o.title}</div>
                  <div className="small">امتیاز: {fa(o.score)} {o.status && `(${ST[o.status]})`}</div>
                  {out.map((t) => <div className="chip" key={t}>اثر بر: {t}</div>)}
                </div>
              );
            })}
          </div>
        </div>
      ))}
      <p className="small">جهت اثر از منظر پایین (رشد) به بالا (مالی) است.</p>
    </div>
  );
}

export default function App() {
  const [orgs, setOrgs] = useState([]);
  const [periods, setPeriods] = useState([]);
  const [org, setOrg] = useState(null);
  const [period, setPeriod] = useState(null);
  const [sc, setSc] = useState(null);
  const [causes, setCauses] = useState([]);
  const [tab, setTab] = useState("score");

  useEffect(() => {
    Promise.all([api("/orgs"), api("/periods")]).then(([o, p]) => {
      setOrgs(o); setPeriods(p);
      if (o.length) setOrg(o[0].id);
      if (p.length) setPeriod(p[p.length - 1].id);
    });
  }, []);
  const load = useCallback(() => {
    if (!org || !period) return;
    api(`/scorecard?org_id=${org}&period_id=${period}`).then(setSc);
    api(`/map?org_id=${org}`).then((m) => setCauses(m.causes));
  }, [org, period]);
  useEffect(load, [load]);

  return (
    <div className="app">
      <aside>
        <h1>BSC Master</h1>
        <select value={period ?? ""} onChange={(e) => setPeriod(+e.target.value)}>
          {periods.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <OrgTree orgs={orgs} sel={org} onSel={setOrg} />
      </aside>
      <main>
        {!sc ? <div className="empty">برای شروع، سرور را اجرا و داده نمونه را بارگذاری کنید.</div> : (<>
          <div className="top">
            <h2>{orgs.find((o) => o.id === org)?.name}</h2>
            <div style={{ textAlign: "left" }}><div className="small">امتیاز کل</div><Dot s={sc.status} v={sc.score} /></div>
          </div>
          <div className="tabs">
            <button className={"tab" + (tab === "score" ? " on" : "")} onClick={() => setTab("score")}>کارت امتیازی</button>
            <button className={"tab" + (tab === "map" ? " on" : "")} onClick={() => setTab("map")}>نقشه استراتژی</button>
          </div>
          {tab === "score" ? <Scorecard sc={sc} periodId={period} reload={load} /> : <StrategyMap sc={sc} causes={causes} />}
        </>)}
      </main>
    </div>
  );
}
