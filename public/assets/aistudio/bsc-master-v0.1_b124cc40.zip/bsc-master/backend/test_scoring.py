from app.scoring import score_indicator, wavg
from app.models import Indicator
def I(**k): return Indicator(**{"method": "achievement", "cap": 1.2, "higher_is_better": True, **k})
def test_achievement_cap(): assert score_indicator(I(), 100, 150) == (120.0, "green")
def test_lower_better(): assert score_indicator(I(higher_is_better=False), 120, 150)[0] == 80.0
def test_threshold(): assert score_indicator(I(method="threshold", yellow_limit=70, green_limit=85), None, 78) == (70.0, "yellow")
def test_threshold_lower(): assert score_indicator(I(method="threshold", higher_is_better=False, yellow_limit=10, green_limit=5), None, 4)[1] == "green"
def test_missing(): assert score_indicator(I(), 100, None) == (None, None) and score_indicator(I(), 0, 5) == (None, None)
def test_wavg_skips_missing(): assert wavg([(100, 1), (None, 5), (50, 1)]) == 75.0
