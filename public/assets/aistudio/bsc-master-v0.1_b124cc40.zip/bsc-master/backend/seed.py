"""داده نمونه برای دمو: هلدینگ ← یک زیرمجموعه، دو دوره، چند هدف/شاخص."""
from app.main import startup, add_org, add_period, add_objective, add_indicator, upsert_measurement, \
    add_cascade, add_cause, OrgIn, PeriodIn, ObjectiveIn, IndicatorIn, MeasurementIn, LinkIn
startup()
H = add_org(OrgIn(name="هلدینگ نمونه"))["id"]
S = add_org(OrgIn(name="زیرمجموعه نمونه (پتروشیمی)", parent_id=H))["id"]
P = [add_period(PeriodIn(name=n))["id"] for n in ("۱۴۰۵-Q1", "۱۴۰۵-Q2")]
def obj(org, p, t): return add_objective(ObjectiveIn(org_id=org, perspective_id=p, title=t))["id"]
def ind(o, **k): return add_indicator(IndicatorIn(objective_id=o, **k))["id"]
def m(i, t, a, p): upsert_measurement(MeasurementIn(indicator_id=i, period_id=p, target=t, actual=a))
hf = obj(H, 1, "رشد سودآوری پرتفوی"); sf = obj(S, 1, "افزایش حاشیه سود عملیاتی")
sc = obj(S, 2, "ارتقای رضایت مشتریان کلیدی"); sp = obj(S, 3, "کاهش توقف‌های برنامه‌ریزی‌نشده")
sg = obj(S, 4, "توسعه شایستگی‌های فنی")
add_cascade(LinkIn(a=sf, b=hf, weight=1)); add_cause(LinkIn(a=sg, b=sp)); add_cause(LinkIn(a=sp, b=sc)); add_cause(LinkIn(a=sc, b=sf))
i1 = ind(sf, title="حاشیه سود عملیاتی", unit="%"); i2 = ind(sc, title="شاخص رضایت مشتری", unit="%", method="threshold", yellow_limit=70, green_limit=85)
i3 = ind(sp, title="ساعات توقف برنامه‌ریزی‌نشده", unit="ساعت", higher_is_better=False)
i4 = ind(sg, title="ساعت آموزش فنی به ازای هر نفر", unit="ساعت")
m(i1, 20, 18, P[0]); m(i2, None, 78, P[0]); m(i3, 120, 150, P[0]); m(i4, 40, 44, P[0])
m(i1, 20, 21, P[1]); m(i2, None, 88, P[1]); m(i3, 120, 115, P[1]); m(i4, 40, 30, P[1])
print("seeded", H, S)
