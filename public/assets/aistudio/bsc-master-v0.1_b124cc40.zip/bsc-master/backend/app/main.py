from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import select

from .models import (Base, Session, engine, OrgUnit, Perspective, Period, Objective, Indicator,
                     Measurement, Cascade, Cause)
from .scoring import score_indicator, status_of, wavg

app = FastAPI(title="BSC Master")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    Base.metadata.create_all(engine)
    with Session() as s:
        if not s.scalars(select(Perspective)).first():
            s.add_all([Perspective(name=n, order=i) for i, n in
                       enumerate(["مالی", "مشتری", "فرایندهای داخلی", "رشد و یادگیری"], 1)])
            s.commit()


def row(o):
    return {c.name: getattr(o, c.name) for c in o.__table__.columns}


class OrgIn(BaseModel):
    name: str
    parent_id: int | None = None


class PeriodIn(BaseModel):
    name: str


class ObjectiveIn(BaseModel):
    org_id: int
    perspective_id: int
    title: str
    weight: float = 1.0


class IndicatorIn(BaseModel):
    objective_id: int
    title: str
    unit: str = ""
    weight: float = 1.0
    higher_is_better: bool = True
    method: str = "achievement"
    cap: float = 1.2
    yellow_limit: float | None = None
    green_limit: float | None = None


class MeasurementIn(BaseModel):
    indicator_id: int
    period_id: int
    target: float | None = None
    actual: float | None = None


class LinkIn(BaseModel):
    a: int  # cascade: child ; cause: from
    b: int  # cascade: parent ; cause: to
    weight: float = 1.0


def create(model, data: dict):
    with Session() as s:
        o = model(**data)
        s.add(o)
        s.commit()
        return row(o)


@app.get("/api/perspectives")
def perspectives():
    with Session() as s:
        return [row(p) for p in s.scalars(select(Perspective).order_by(Perspective.order))]


@app.get("/api/orgs")
def orgs():
    with Session() as s:
        return [row(o) for o in s.scalars(select(OrgUnit))]


@app.post("/api/orgs")
def add_org(d: OrgIn):
    return create(OrgUnit, d.model_dump())


@app.get("/api/periods")
def periods():
    with Session() as s:
        return [row(p) for p in s.scalars(select(Period).order_by(Period.id))]


@app.post("/api/periods")
def add_period(d: PeriodIn):
    return create(Period, d.model_dump())


@app.post("/api/objectives")
def add_objective(d: ObjectiveIn):
    return create(Objective, d.model_dump())


@app.post("/api/indicators")
def add_indicator(d: IndicatorIn):
    if d.method not in ("achievement", "threshold"):
        raise HTTPException(422, "method must be achievement or threshold")
    if d.method == "threshold" and (d.yellow_limit is None or d.green_limit is None):
        raise HTTPException(422, "threshold method needs yellow_limit and green_limit")
    return create(Indicator, d.model_dump())


@app.put("/api/measurements")
def upsert_measurement(d: MeasurementIn):
    with Session() as s:
        m = s.scalars(select(Measurement).filter_by(indicator_id=d.indicator_id, period_id=d.period_id)).first()
        if m:
            m.target, m.actual = d.target if d.target is not None else m.target, d.actual
        else:
            m = Measurement(**d.model_dump())
            s.add(m)
        s.commit()
        return row(m)


@app.post("/api/cascade")
def add_cascade(d: LinkIn):
    return create(Cascade, {"child_id": d.a, "parent_id": d.b, "weight": d.weight})


@app.post("/api/causes")
def add_cause(d: LinkIn):
    return create(Cause, {"from_id": d.a, "to_id": d.b})


def build_scorecard(s, org_id: int, period_id: int, _cache=None):
    """امتیاز هر هدف از شاخص‌های خودش؛ امتیاز تراز‌شده از اهداف فرزند (در صورت وجود)."""
    _cache = {} if _cache is None else _cache
    meas = {m.indicator_id: m for m in s.scalars(select(Measurement).filter_by(period_id=period_id))}
    persp = list(s.scalars(select(Perspective).order_by(Perspective.order)))
    objs = list(s.scalars(select(Objective).filter_by(org_id=org_id)))
    out = []
    for p in persp:
        o_list = []
        for o in [x for x in objs if x.perspective_id == p.id]:
            inds = []
            for i in s.scalars(select(Indicator).filter_by(objective_id=o.id)):
                m = meas.get(i.id)
                sc, st = score_indicator(i, m.target if m else None, m.actual if m else None)
                inds.append({**row(i), "target": m.target if m else None, "actual": m.actual if m else None,
                             "score": sc, "status": st})
            own = wavg([(i["score"], i["weight"]) for i in inds])
            kids = []
            for c in s.scalars(select(Cascade).filter_by(parent_id=o.id)):
                child = s.get(Objective, c.child_id)
                cs = objective_score(s, child, meas)
                kids.append({"objective_id": child.id, "org_id": child.org_id, "title": child.title,
                             "weight": c.weight, "score": cs})
            aligned = wavg([(k["score"], k["weight"]) for k in kids])
            o_list.append({**row(o), "indicators": inds, "score": own, "status": status_of(own),
                           "children": kids, "aligned_score": aligned, "aligned_status": status_of(aligned)})
        ps = wavg([(o["score"], o["weight"]) for o in o_list])
        out.append({"perspective": row(p), "objectives": o_list, "score": ps, "status": status_of(ps)})
    total = wavg([(p["score"], 1.0) for p in out])
    return {"org_id": org_id, "period_id": period_id, "perspectives": out, "score": total, "status": status_of(total)}


def objective_score(s, o, meas):
    pairs = []
    for i in s.scalars(select(Indicator).filter_by(objective_id=o.id)):
        m = meas.get(i.id)
        pairs.append((score_indicator(i, m.target if m else None, m.actual if m else None)[0], i.weight))
    return wavg(pairs)


@app.get("/api/scorecard")
def scorecard(org_id: int, period_id: int):
    with Session() as s:
        if not s.get(OrgUnit, org_id):
            raise HTTPException(404, "org not found")
        return build_scorecard(s, org_id, period_id)


@app.get("/api/map")
def strategy_map(org_id: int):
    with Session() as s:
        ids = [o.id for o in s.scalars(select(Objective).filter_by(org_id=org_id))]
        causes = s.scalars(select(Cause).filter(Cause.from_id.in_(ids)))
        return {"causes": [row(c) for c in causes]}
