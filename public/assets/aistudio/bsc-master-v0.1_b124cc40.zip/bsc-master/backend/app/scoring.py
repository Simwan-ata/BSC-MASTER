"""محاسبه امتیاز شاخص‌ها و تجمیع آن‌ها. امتیاز در مقیاس ۰ تا ۱۲۰ (سقف قابل تنظیم) است."""


def status_of(score: float | None) -> str | None:
    if score is None:
        return None
    return "green" if score >= 90 else "yellow" if score >= 70 else "red"


def score_indicator(ind, target, actual):
    """ind: Indicator. خروجی: (score, status) یا (None, None) اگر داده کافی نیست."""
    if actual is None:
        return None, None
    if ind.method == "threshold":
        y, g = ind.yellow_limit, ind.green_limit
        if y is None or g is None:
            return None, None
        if ind.higher_is_better:
            st = "green" if actual >= g else "yellow" if actual >= y else "red"
        else:
            st = "green" if actual <= g else "yellow" if actual <= y else "red"
        return {"green": 100.0, "yellow": 70.0, "red": 30.0}[st], st
    # achievement
    if target in (None, 0):
        return None, None
    if ind.higher_is_better:
        ratio = actual / target
    else:
        ratio = target / actual if actual > 0 else ind.cap
    score = max(0.0, min(ratio, ind.cap)) * 100
    return round(score, 1), status_of(score)


def wavg(pairs):
    """میانگین وزنی روی آیتم‌های دارای امتیاز؛ وزن آیتم‌های بدون داده نادیده گرفته می‌شود."""
    valid = [(s, w) for s, w in pairs if s is not None and w > 0]
    tw = sum(w for _, w in valid)
    return round(sum(s * w for s, w in valid) / tw, 1) if tw else None
