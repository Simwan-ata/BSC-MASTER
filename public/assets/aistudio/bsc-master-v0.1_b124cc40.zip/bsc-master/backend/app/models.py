import os
from sqlalchemy import ForeignKey, String, Float, UniqueConstraint, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

DB_URL = os.getenv("DATABASE_URL", "postgresql+psycopg://bsc:bsc@localhost:5432/bsc")
engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {})
Session = sessionmaker(engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class OrgUnit(Base):  # هلدینگ ← زیرمجموعه ← شرکت/واحد
    __tablename__ = "org_unit"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("org_unit.id"))


class Perspective(Base):
    __tablename__ = "perspective"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    order: Mapped[int]


class Period(Base):  # برچسب دوره به‌صورت متن (مثلاً «۱۴۰۵-Q۱») تا تقویم جلالی بدون وابستگی ذخیره شود
    __tablename__ = "period"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50), unique=True)


class Objective(Base):
    __tablename__ = "objective"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("org_unit.id"))
    perspective_id: Mapped[int] = mapped_column(ForeignKey("perspective.id"))
    title: Mapped[str] = mapped_column(String(300))
    weight: Mapped[float] = mapped_column(default=1.0)


class Indicator(Base):
    __tablename__ = "indicator"
    id: Mapped[int] = mapped_column(primary_key=True)
    objective_id: Mapped[int] = mapped_column(ForeignKey("objective.id"))
    title: Mapped[str] = mapped_column(String(300))
    unit: Mapped[str] = mapped_column(String(30), default="")
    weight: Mapped[float] = mapped_column(default=1.0)
    higher_is_better: Mapped[bool] = mapped_column(default=True)
    method: Mapped[str] = mapped_column(String(20), default="achievement")  # achievement | threshold
    cap: Mapped[float] = mapped_column(default=1.2)          # سقف نسبت تحقق (روش achievement)
    yellow_limit: Mapped[float | None] = mapped_column()      # حد زرد (روش threshold)
    green_limit: Mapped[float | None] = mapped_column()       # حد سبز (روش threshold)


class Measurement(Base):
    __tablename__ = "measurement"
    __table_args__ = (UniqueConstraint("indicator_id", "period_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    indicator_id: Mapped[int] = mapped_column(ForeignKey("indicator.id"))
    period_id: Mapped[int] = mapped_column(ForeignKey("period.id"))
    target: Mapped[float | None] = mapped_column()
    actual: Mapped[float | None] = mapped_column()


class Cascade(Base):  # هدف فرزند (زیرمجموعه) ← هدف والد (هلدینگ) با وزن مشارکت
    __tablename__ = "cascade"
    id: Mapped[int] = mapped_column(primary_key=True)
    child_id: Mapped[int] = mapped_column(ForeignKey("objective.id"))
    parent_id: Mapped[int] = mapped_column(ForeignKey("objective.id"))
    weight: Mapped[float] = mapped_column(default=1.0)


class Cause(Base):  # رابطه علت‌ومعلولی نقشه استراتژی
    __tablename__ = "cause"
    id: Mapped[int] = mapped_column(primary_key=True)
    from_id: Mapped[int] = mapped_column(ForeignKey("objective.id"))
    to_id: Mapped[int] = mapped_column(ForeignKey("objective.id"))
